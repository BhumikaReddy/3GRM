#name : 4_recursion.py

"""
def find(mylist, x) :
	if not mylist:
		return False
	elif mylist[0] == x :
		return True
	else:
		return find(mylist[1:], x)
		

x = [11, 33, 22, 44]
print(find(x, 22))
print(find(x, 5))
"""

"""
def find_(mylist, x, i) :
	if i == len(mylist):
		return -1
	elif mylist[i] == x :
		return i
	else:
		return find_(mylist, x, i + 1)

		
def find(mylist, x) :
	return find_(mylist, x, 0)

x = [11, 33, 22, 44]
print(find(x, 22))
print(find(x, 5))
"""
def find(mylist, x, i = 0) :
	if i == len(mylist):
		return -1
	elif mylist[i] == x :
		return i
	else:
		return find(mylist, x, i + 1)

x = [11, 33, 22, 44]
print(find(x, 22))
print(find(x, 5))


