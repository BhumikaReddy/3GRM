# name: 5_map.py

# given a list of strings, find their corresponding lengths

def what1(x):
	res = []
	for w in x:
		res.append(len(w))
	return res

a = [ 'apple', 'pineapple', 'fig', 'mangoes' ]
b = what1(a)
print(b) # 5 9 3 7

# given a list of strings, convert to uppercase

def what2(x):
	res = []
	for w in x:
		res.append(str.upper(w))
	return res

a = [ 'apple', 'pineapple', 'fig', 'mangoes' ]
b = what2(a)
print(b) # APPLE PINEAPPLE FIG MANGOES

# given a list of numbers, square each number
def what3(x):
	res = []
	for w in x:
		res.append(w * w)
	return res

a = [11, 33, 22, 44]
b = what3(a)
print(b)

# map : allows us to walk thro an iterable
#		apply some function
#		collect the result


a = [ 'apple', 'pineapple', 'fig', 'mangoes' ]
# map(<callable>, <iterable>)
b = list(map(len, a))
print(b)

b = list(map(str.upper, a))
print(b)

a = [11, 33, 22, 44]
b = list(map(lambda x : x * x, a))
print(b)




