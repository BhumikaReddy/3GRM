# name: 2_recursion.py
# Euclid's algorithm to find the greatest common divisor
def gcd(m, n):
	if m == n :
		res = m

	elif m > n :
		res = gcd(m -n, n)
		# 3 
		# 4
	else:
		res = gcd(m, n - m)
		# 2 
		# 5
	return res

print("gcd : ", gcd(65, 91))
#                 1


# 1. gcd(65, 91)
# 2. gcd(65, 26)
# 3. gcd(39, 26)
# 4, gcd(13, 26)
# 5. gcd(13, 13)

