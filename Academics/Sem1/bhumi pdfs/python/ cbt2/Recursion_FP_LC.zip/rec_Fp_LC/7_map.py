# name: 7_map.py
# use the os module
# os.listdir("path") gives the output of ls command
# path = "." ; list in the current directory

# os.path.getsize(filename) => size of file in bytes

import os
# make an iterable of all files
for size in map(os.path.getsize , os.listdir(".")) :
	print(size)

def get_name_size(name):
	return (name, os.path.getsize(name))
for pair in map(get_name_size , os.listdir(".")) :
	print(pair[0],  "=>", pair[1])

