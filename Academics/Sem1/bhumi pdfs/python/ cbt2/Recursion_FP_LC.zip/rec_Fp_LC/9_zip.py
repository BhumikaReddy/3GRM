# name: 9_zip.py

# zip :
#	combining two iterables
a = [1, 2, 3, 4, 5]
b = list(map(lambda x : x * x * x, a))
print(a)
print(b)
# zip : takes # of iterables and returns a single iterable of tuples
#	obtained by mapping the corresponding elements
print(list(zip(a, b)))

# filenames
import os
names = os.listdir(".")
sizes = list(map(os.path.getsize, names))
#print(list(zip(names, sizes)))
for pair in sorted(zip(names, sizes), key = lambda x : x[1]):
	print(pair[0],  "=>", pair[1])

