# name: 8_map_filter_reduce.py

print(list(map(lambda x : x % 2, range(5))))  #[0, 1, 0, 1, 0]
print(list(filter(lambda x : x % 2, range(5))))  #[1, 3]
# map:
#	returns an iterable
#	input : n elements
#	output : n elements

#   output : not the input, result of the fn call on the input

# filter:
#	returns an iterable
#	input : n elements
#	output : anything between 0 and n elements

# 	output : has elements given in the input itself
#			not the result of the function call

#			gives the output only when the function returns a true value


a = [ 'rama', 'krishna', 'balarama', 'lakshmana', 'dasharatha', 'sita' ]
# pickup all words which have r
print(list(filter(lambda s : 'r' in s , a)))
# pickup all words whose length exceeds 4
print(list(filter(lambda s : len(s) > 4 , a)))

# convert all strings to uppercase and find all strings whose length exceeds 4
# terrible code
print(list(filter(lambda s : len(s) > 4 , map(str.upper , a))))

# good code
print(list(map(str.upper, filter(lambda s : len(s) > 4, a))))

import functools

print(functools.reduce(int.__add__, range(10)))
# reduce:
#	input : n elements
#	output : 1 element

#   callable : takes two arguments
#	called n - 1 times
def foo(x, y):
	print("foo : ", x, y)
	return x + y
print(functools.reduce(foo, [11, 22, 33, 44]))

# n calls
# 100 is the initial value
print(functools.reduce(foo, [11, 22, 33, 44], 100))

#names = [ 'nagabhushana', 'satya', 'kumar' ]
names = [ 'amar', 'bharatha', 'chandra', 'deepa', 'eshwara']
# output : nsk
print(functools.reduce(lambda x, y : x + y[0], names, ""))

# output a single string
words = ['raja', 'ram ', 'mohan ', 'roy']
print(functools.reduce(lambda x, y : x + y, words))


# find factorial of n in a single statement
n = 5
print(functools.reduce(int.__mul__ , range(1, n + 1)))















