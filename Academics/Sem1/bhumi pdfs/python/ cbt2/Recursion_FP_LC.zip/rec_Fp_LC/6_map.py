# name : 6_map.py
# given a number, generate its multiples with numbers from 1 to n
# generate multiplication table for a given number
n = int(input("enter a number : "))
#print(list(range(n, n * 10 + 1, n)))

def foo(i) :
	# n : global variable
	prod = n * i # prod : local variable
	#print(n, " X ", i, " = ", prod)
	return str(n) + " X " + str(i) + " = " + str(prod) + "\n"

for i in range(1, 11):
	#foo(i)
	print(foo(i), end = "")

#print(list(map(foo, range(1, 11))))	
for line in map(foo, range(1, 11)):
	print(line, end = "")
