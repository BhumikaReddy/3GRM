# name : 1_recursion.py
# recursion
# factorial :
#	n! = n x (n-1)!  for n > 0
#      = 1  for n = 0

def fact(n):
	if n == 0 :
		res = 1
	else:
		res = n * fact(n - 1)
	return res	

print(fact(5)) # 120
print(fact(0)) # 1
