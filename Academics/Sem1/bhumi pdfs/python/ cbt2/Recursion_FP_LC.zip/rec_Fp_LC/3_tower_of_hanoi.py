# name: 3_tower_of_hanoi.py

# tower of hanoi
# if there are disks(say n) then
#	move n-1 disks from f to u using t
#	move one disk from f to t
#	move n-1 disks from u to t using f


def move(n, f, t, u) :
	if n > 0 :
		move(n - 1, f, u, t)
		print(f, "=>", t)
		move(n - 1, u, t, f)

move(5, 1, 3, 2)
