# name : 0_intro_set.py
# set :
#	is a data structure
#	has # of elements
#	elements are unique
#	make a set : { }
a = { 10, 30, 10, 40, 20, 50, 30 }
print(a) # elements are unique; there is no particular order

# list : l
#	ith element : l[i]
#	next element : l[i + 1]
#	previous element : l[i - 1]
#	is a sequence
#	concept of position for each element

# set :
#	not sequence
#	no concept of an element in a particular position
#	represents a finite set of math

# set in an iterable
for e in a :
	print(e, end =  " ")
print()


# check for membership
print(100 in a) # False
print(20 in a) # True

# set operations
s1 = {1, 2, 3, 4, 5}
s2 = {1, 3, 5, 7, 9}
# union
print(s1 | s2) # {1, 2, 3, 4, 5, 7, 9}
# intersection
print(s1 & s2) # {1, 3, 5}
# set difference
print(s1 - s2) # {2, 4}
# symmetric difference
print(s1 ^ s2) # {2, 4, 7, 9}


#print("what : ", s1[0])# TypeError: 'set' object does not support indexing

# creates a set ; initialized by called set - which is called the constructor
#	of set
s3 = set()
s4 = set([11, 33, 22, 11, 33, 11, 11, 44, 22])
print(s3)
print(s4)

s5 = set("mississippi")
print(s5) # {'s', 'i', 'm', 'p'}

# string : double or single quote : string should be on a single line
# 			3 double quotes or 3 single quotes : string can appear or span
#		multiple lines
str1 = """do not trouble trouble 
till trouble
troubles you"""
#print(str1.split())
print(set(str1.split()))
"""
# output in order
# version 1
l = list(set(str1.split()))
l.sort()
print(l)
"""
# version 2:
print(sorted(set(str1.split())))

str2 = """betsy botsome bought some butter but the butter was bitter
betsy botsome bought some better butter to make the bitter butter better"""
print(sorted(set(str2.split())))




























