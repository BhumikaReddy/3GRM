# name: 5_dict.py

all = """sanskrit kalidasa shakuntala
english r_k_narayan malgudi_days
kannada kuvempu ramayanadarshanam
sanskrit bhasa swapnavasavadatta
kannada kuvempu malegalalli_madumagalu
english r_k_narayan dateless_diary
kannada karanta chomanadudi
sanskrit baana harshacharita
kannada karanta sarasatammana_Samadhi
sanskrit kalidasa malavikagnimitra
sanskrit kalidasa raghuvamsha
sanskrit baana kadambari
sanskrit bhasa pratijnayogandhararayana"""

# find the # of books
print("# of books : ", len(all.split('\n')))
#for l in enumerate(all.split('\n')) :
#	print(l)
#print(l)

# find the number of languages
langset = set()
for line in all.split('\n'):
	#print(line.split()[0])
	langset.add(line.split()[0])
#print(langset)
print("# of lang : ", len(langset))


# count the number of books in each language
lang_book_count = {}
for line in all.split('\n'):
	lang = line.split()[0] 
	#print(lang)
	if lang not in lang_book_count :
		lang_book_count[lang] = 0
	lang_book_count[lang] += 1

for lang in lang_book_count :
	print(lang, " => ",  lang_book_count[lang])











