# name : 6_dict.py
all = """sanskrit kalidasa shakuntala
english r_k_narayan malgudi_days
kannada kuvempu ramayanadarshanam
sanskrit bhasa swapnavasavadatta
kannada kuvempu malegalalli_madumagalu
english r_k_narayan dateless_diary
kannada karanta chomanadudi
sanskrit baana harshacharita
kannada karanta sarasatammana_Samadhi
sanskrit kalidasa malavikagnimitra
sanskrit kalidasa raghuvamsha
sanskrit baana kadambari
sanskrit bhasa pratijnayogandhararayana"""

# find list of authors for each language
# dict of sets
lang_author = {}
for line in all.split('\n'):
	(lang, author) = line.split()[:2]
#	print(lang, author)
	if lang not in lang_author:
		lang_author[lang] = set()
	lang_author[lang].add(author)

for lang in lang_author:
	print(lang)
	for author in lang_author[lang]:
		print("\t", author)





