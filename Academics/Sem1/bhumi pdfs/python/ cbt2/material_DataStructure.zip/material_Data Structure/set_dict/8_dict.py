# name: 8_dict.py

all = """sanskrit kalidasa shakuntala
english r_k_narayan malgudi_days
kannada kuvempu ramayanadarshanam
sanskrit bhasa swapnavasavadatta
kannada kuvempu malegalalli_madumagalu
english r_k_narayan dateless_diary
kannada karanta chomanadudi
sanskrit baana harshacharita
kannada karanta sarasatammana_Samadhi
sanskrit kalidasa malavikagnimitra
sanskrit kalidasa raghuvamsha
sanskrit baana kadambari
sanskrit bhasa pratijnayogandhararayana"""

# find list of titles of each author of each lang
# soln: dict of dict of list

info = {}
for line in all.split('\n'):
	(lang, author, title) = line.split()
	if lang not in info :
		info[lang] = {}
	if author not in info[lang] :
		info[lang][author] = []
	info[lang][author].append(title)

for lang in info:
	print(lang)
	for author in info[lang]:
		print("\t", author)
		for title in info[lang][author]:
			print("\t\t", title)
	










	
