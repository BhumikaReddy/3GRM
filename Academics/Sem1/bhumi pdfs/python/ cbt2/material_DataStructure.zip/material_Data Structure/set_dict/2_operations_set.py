# name : 2_operations_set.py
# create sets with the required elements

# make a set of  numbers from 2 to n
#
n = 10
#s = {}  #not an empty set

"""
# not good; it works
# version 1
s = set() 
for e in range(2, n + 1):
	s.add(e)
print(s, type(s))
"""

# verson 2
s = set(range(2, n + 1))
print(s)

#-------------------------------------

# is set empty or not
s1 = set()
s2 = set("fool")
print("empty : ", len(s1) == 0)
print("empty : ", len(s2) == 0)
"""
if len(s1) == 0 :
	print("empty")
else:
	print("non empty")

if len(s2) == 0 :
	print("empty")
else:
	print("non empty")
"""
if s1 :
	print("empty")
else:
	print("non empty")

if s2 :
	print("empty")
else:
	print("non empty")
# empty data structure => False
# non-empty data structure => True

# remove elements from a set
s3 = set(range(10)) # 0 .. 9
# remove 2 4 6 8  # remove multiples of 2
for i in range(2, 10, 2) : 
	s3.remove(i)
print(s3)

s3 = set(range(10)) # 0 .. 9
s3 = s3 - set(range(2, 10, 2))
print(s3)













