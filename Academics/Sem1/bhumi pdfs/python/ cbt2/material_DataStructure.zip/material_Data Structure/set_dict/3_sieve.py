# name: 3_sieve.py
# generate prime numbers (no division; most efficient algorithm)
# sieve of Eratosthenes
# get a number(say n)
# make a set of numbers from 2 to n - say sieve
# while sieve is not empty
#	find the smallest (small)
#	print it (that is a prime)
#	remove small and its multiples from the sieve

n = int(input("Enter an integer : "))
# make a set of numbers from 2 to n - say sieve
sieve = set(range(2, n + 1))
#print(sieve)
while sieve :
	small = min(sieve)
	print(small, end = " ")
	sieve -= set(range(small, n + 1,small))

