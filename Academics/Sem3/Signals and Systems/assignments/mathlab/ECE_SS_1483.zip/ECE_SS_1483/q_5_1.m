syms z;

h(z)=z/(z-1);

h(t)=iztrans(h(z));

display(h(t)); 